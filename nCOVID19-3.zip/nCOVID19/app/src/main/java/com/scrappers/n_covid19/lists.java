package com.scrappers.n_covid19;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableWrapper;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ListView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import static com.scrappers.n_covid19.MainActivity.btn;

public class lists extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lists);
            check_For_OnClick();
    }

    public void define_List1(){

        //all the data goes here
        ArrayList<String> text=new ArrayList<>();
        text.add("<h1>Geographic distribution</h1>\n" +
                "\n" +
                "Since the first reports of cases from Wuhan, a city in the Hubei Province of China, at the end of 2019, more than 80,000 COVID-19 cases have been reported in China; \n" +
                "\n" +
                "these include all laboratory-confirmed cases as well as clinically diagnosed cases in the Hubei Province.\n" +
                "\n" +
                " A joint World Health Organization (WHO)-China fact-finding mission estimated that the epidemic in China peaked between late January and early February 2020 .");


        text.add("Transmission \n" +
                "\n" +
                "Epidemiologic investigation in Wuhan at the beginning of the outbreak identified an initial association with a seafood market (WetMarket)that sold live animals, where most patients had worked or visited and which was subsequently closed for disinfection .\n" +
                "\n" +
                "However, as the outbreak progressed, person-to-person spread became the main mode of transmission.\n" +
                "\n" +
                "Person-to-person spread of severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) is thought to occur mainly via respiratory droplets, resembling the spread of influenza.\n" +
                "\n" +
                "With droplet transmission, virus released in the respiratory secretions when a person with infection coughs, sneezes, or talks can infect another person if it makes direct contact with the mucous membranes; infection can also occur if a person touches an infected surface and then touches his or her eyes, nose, or mouth. \n" +
                "\n" +
                "Droplets typically do not travel more than six feet (about two meters) and do not linger in the air. \n" +
                "\n" +
                "However, given the current uncertainty regarding transmission mechanisms, airborne precautions are recommended routinely in some countries and in the setting of certain high-risk procedures in others.\n" +
                "\n" +
                "Viral RNA levels appear to be higher soon after symptom onset compared with later in the illness , this raises the possibility that transmission might be more likely in the earlier stage of infection, but additional data are needed to confirm this hypothesis.\n" +
                "\n" +
                "SARS-CoV-2 RNA has been detected in blood and stool specimens . Live virus has been cultured from stool in some cases , but according to a joint WHO-China report, fecal-oral transmission did not appear to be a significant factor in the spread of infection.");
        text.add("VIROLOGY\n" +
                "\n" +
                "Full-genome sequencing and phylogenic analysis indicated that the coronavirus that causes COVID-19 is a betacoronavirus in the same subgenus as the severe acute respiratory syndrome (SARS) virus (as well as several bat coronaviruses), but in a different clade. \n" +
                "\n" +
                "The structure of the receptor-binding gene region is very similar to that of the SARS coronavirus, and the virus has been shown to use the same receptor, the angiotensin-converting enzyme 2 (ACE2), for cell entry .\n" +
                "\n" +
                "The Coronavirus Study Group of the International Committee on Taxonomy of Viruses has proposed that this virus be designated severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) .\n" +
                "\n" +
                "The Middle East respiratory syndrome (MERS) virus, another betacoronavirus, appears more distantly related .\n" +
                "\n" +
                "The closest RNA sequence similarity is to two bat coronaviruses, and it appears likely that bats are the primary source; whether COVID-19 virus is transmitted directly from bats or through some other mechanism (eg, through an intermediate host) is unknown .\n");
        //all the illustrating images for the data goes here
        ArrayList<Drawable> imgls=new ArrayList<>();


        imgls.add(add_From_Drawable("epi1.jpg"));
        imgls.add(add_From_Drawable("transmission.jpg"));
        imgls.add(add_From_Drawable("Virology.png"));
        //definers
        CustomListAdapter cstmls=new CustomListAdapter(this,text,imgls);
        ListView ls=findViewById(R.id.listview);
        ls.setAdapter(cstmls);
    }

    public void define_List2(){

        //all the data goes here
        ArrayList<String> text=new ArrayList<>();
        text.add("btn2");
        text.add("2");
        text.add("3");
        //all the illustrating images for the data goes here
        ArrayList<Drawable> imgls=new ArrayList<>();
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        //definers
        CustomListAdapter cstmls=new CustomListAdapter(this,text,imgls);
        ListView ls=findViewById(R.id.listview);
        ls.setAdapter(cstmls);
    }
    public void define_List3(){

        //all the data goes here
        ArrayList<String> text=new ArrayList<>();
        text.add("btn3");
        text.add("2");
        text.add("3");
        //all the illustrating images for the data goes here
        ArrayList<Drawable> imgls=new ArrayList<>();
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        //definers
        CustomListAdapter cstmls=new CustomListAdapter(this,text,imgls);
        ListView ls=findViewById(R.id.listview);
        ls.setAdapter(cstmls);
    }
    public void define_List4(){

        //all the data goes here
        ArrayList<String> text=new ArrayList<>();
        text.add("btn4");
        text.add("2");
        text.add("3");
        //all the illustrating images for the data goes here
        ArrayList<Drawable> imgls=new ArrayList<>();
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        //definers
        CustomListAdapter cstmls=new CustomListAdapter(this,text,imgls);
        ListView ls=findViewById(R.id.listview);
        ls.setAdapter(cstmls);
    }
    public void define_List5(){

        //all the data goes here
        ArrayList<String> text=new ArrayList<>();
        text.add("btn5");
        text.add("2");
        text.add("3");
        //all the illustrating images for the data goes here
        ArrayList<Drawable> imgls=new ArrayList<>();
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        imgls.add(add_From_Drawable(""));
        //definers
        CustomListAdapter cstmls=new CustomListAdapter(this,text,imgls);
        ListView ls=findViewById(R.id.listview);
        ls.setAdapter(cstmls);
    }

    public void check_For_OnClick(){
        switch (btn){
            case 1:
                define_List1();
                break;
            case 2:
                define_List2();
                break;
            case 3:
                define_List3();
                break;
            case 4:
                define_List4();
                break;
            case 5:
                define_List5();
                break;

                default:
                    break;
        }
    }

    public Drawable add_From_Drawable(String fileName){
       Drawable drawable=null;
        try {
            // get input stream
            InputStream ims = getAssets().open(fileName);
            // load image as Drawable
             drawable = Drawable.createFromStream(ims, null);
        }
        catch(IOException ex) {
            ex.printStackTrace();
        }
        return drawable;
    }
}
