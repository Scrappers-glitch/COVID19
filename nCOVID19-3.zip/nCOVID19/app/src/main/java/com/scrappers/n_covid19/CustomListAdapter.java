package com.scrappers.n_covid19;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import org.sufficientlysecure.htmltextview.HtmlTextView;

import java.util.ArrayList;

public class CustomListAdapter extends ArrayAdapter<String> implements Filterable {

    private Activity context;
    private ArrayList<String> maintitle;
    private ArrayList<Drawable> image;


    /// wooohooo warning critical fatal warning >>>this is the constructor should be the same name as the class name
    public CustomListAdapter(Activity context, ArrayList<String> maintitle, ArrayList<Drawable> image) {
        super(context, R.layout.list_of_info, maintitle);
        // TODO Auto-generated constructor stub

        this.context = context;
        this.maintitle = maintitle;
        this.image = image;


    }


    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        //define the layout inflater & the view to inflate a custom layout from a xml layout file
        LayoutInflater inflater = context.getLayoutInflater();
        final View rowView = inflater.inflate(R.layout.list_of_info, null, true);

        //define your components

        HtmlTextView text=rowView.findViewById(R.id.data);

        ImageView imgview=rowView.findViewById(R.id.illustrator);


        text.setText(maintitle.get(position));
        imgview.setImageDrawable(image.get(position));

//        //List View Animation
//        Animation animation = AnimationUtils.loadAnimation(context,R.anim.fade_in);
//        rowView.startAnimation(animation);
//

        //finish your function by returning the custom view layout
        return rowView;

    }









}

